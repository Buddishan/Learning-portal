package com.linhtch90.psnbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PsnBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
