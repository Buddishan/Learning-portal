import React from 'react';
import AppContainer from './components/AppContainer';
import "./App.css";

function App() {
  return (
    <AppContainer />
  );
}

export default App;
