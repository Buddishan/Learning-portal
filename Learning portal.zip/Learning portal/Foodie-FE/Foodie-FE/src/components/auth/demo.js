{
    "uid": "00q1uHhWZFUCEUTwfCr9UywP7ss1",
    "email": "it21150098@my.sliit.lk",
    "emailVerified": true,
    "displayName": "it21150098 Rushanth B",
    "isAnonymous": false,
    "photoURL": "https://lh3.googleusercontent.com/a/AGNmyxYrZ_4dqBOA0u0xjkHxERDWZoiozNrPpuVsAvDD=s96-c",
    "providerData": [
        {
            "providerId": "google.com",
            "uid": "112584921000259109405",
            "displayName": "it21150098 Rushanth B",
            "email": "it21150098@my.sliit.lk",
            "phoneNumber": null,
            "photoURL": "https://lh3.googleusercontent.com/a/AGNmyxYrZ_4dqBOA0u0xjkHxERDWZoiozNrPpuVsAvDD=s96-c"
        }
    ],
    "stsTokenManager": {
        "refreshToken": "APZUo0T6vRh2njhzb8HlU_9NXWg8vXYVKxCgC5BUOk2HpjutmOH_6X37lYPwf0CbYML1bwvfbmPj_AzBWvpyONJ9MLjnKD9VD8zDaauUzS0hhgGG4k_rFWNBF8vOTQZ-pTGCBK0WBCNi7wbprlRPFTKLIY0q8tM66ezaySe-gCy7lcmKBiFQgP9QvnGLRedgulysoezFEFFUbHtUQC2iqK-vSkRV_Q-y9YiMX0n8P6HNO2ycCFmqdhfhCfMFtLXM8sER-dohcobNyIxy1Tm3SFy8x3zSAR9YXIgCKsQD4l7seCoC3B24Blo09rjcgaTcMekSNja6zC98Ey9N4reNc1ELVfINzrtwQwYKFSbXp17lzyw9fFD33__WZUyYFLtdleL5qndypFq11eSvIvnUVEjYvJm1zV9x4cqtzxPz-VTZkjhUWhciCStt1fZ21KzN6MElyFBQPro6",
        "accessToken": "eyJhbGciOiJSUzI1NiIsImtpZCI6ImU3OTMwMjdkYWI0YzcwNmQ2ODg0NGI4MDk2ZTBlYzQzMjYyMjIwMDAiLCJ0eXAiOiJKV1QifQ.eyJuYW1lIjoiaXQyMTE1MDA5OCBSdXNoYW50aCBCIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FHTm15eFlyWl80ZHFCT0EwdTB4amtIeEVSRFdab2lvek5yUHB1VnNBdkREPXM5Ni1jIiwiaXNzIjoiaHR0cHM6Ly9zZWN1cmV0b2tlbi5nb29nbGUuY29tL3BhZi1zb2NpYWwtbWVkaWEiLCJhdWQiOiJwYWYtc29jaWFsLW1lZGlhIiwiYXV0aF90aW1lIjoxNjgyNjI4MjY5LCJ1c2VyX2lkIjoiMDBxMXVIaFdaRlVDRVVUd2ZDcjlVeXdQN3NzMSIsInN1YiI6IjAwcTF1SGhXWkZVQ0VVVHdmQ3I5VXl3UDdzczEiLCJpYXQiOjE2ODI2MjgyNjksImV4cCI6MTY4MjYzMTg2OSwiZW1haWwiOiJpdDIxMTUwMDk4QG15LnNsaWl0LmxrIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImZpcmViYXNlIjp7ImlkZW50aXRpZXMiOnsiZ29vZ2xlLmNvbSI6WyIxMTI1ODQ5MjEwMDAyNTkxMDk0MDUiXSwiZW1haWwiOlsiaXQyMTE1MDA5OEBteS5zbGlpdC5sayJdfSwic2lnbl9pbl9wcm92aWRlciI6Imdvb2dsZS5jb20ifX0.mlIahj7289ZLA7Cp0_ajc5c0to3tyOTyoGwt9De6jyfshS2kPfPnQ2rAzcs9oE8Ox6tagEfWc2LPZxa9qqxP7v0y_bYzKJds2lUwIGilOWGlC6k6nX4TWefwRa7K_fi3YatdBQTQHm2lcj7oLiuacQbn7WgT5MYfurQtHwadLjRNikGDFatZM99qNN0Jy3Apo6gMYiPY1PLLc7tp-DT9YHtlQDvLrLUDlLxucb03MaTbgIOfwna6JDZqi8BNA0zYGImqj20fLa38KrFJUSb4E63-X3tHogqifAUzWxidE26BCDyjsT_2Kgu3PXafiLBq8mPgVnAIed2jpii-Vmwq8w",
        "expirationTime": 1682631869143
    },
    "createdAt": "1682627414213",
    "lastLoginAt": "1682628269248",
    "apiKey": "AIzaSyCbex1TgLJ5_nk2NbPuwPSn-vu4bJw2gO4",
    "appName": "[DEFAULT]"
}

// after sign in
{
    "firstName": "it21150098 Rushanth B",
    "lastName": " ",
    "email": "it21150098@my.sliit.lk",
    "password": "PAF2023@@",
    "role": "user"
}